package model.iface;

import java.awt.*;

public interface IControllable {
    public Component getComponent();
}
