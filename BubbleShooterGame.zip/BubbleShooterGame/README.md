# BubbleShooterGame

Team Members: Draghici Andreea and Ciontu Claudia

## Introduction
---------------------------
- Human Computer Interaction Project , 4-th year
- Java Swing Application 
- IDEA: IntelliJ IDEA
- Using JInput API.


## Resources:
----------------------------
- JInput API: https://jinput.github.io/jinput/
- JInput Code Example: https://github.com/Keabot-Studios/SuperIn
- BubbleShooter Examples: https://github.com/search?l=Java&q=bubble+shooter&type=Repositories
- How To Use JInput: https://stackoverflow.com/questions/47312795/how-to-use-controllerlistener-jinput-java
- JInput API Topics: https://github.com/topics/jinput

## History
-----------------------------

- Version 1.0 - Initial version of release
